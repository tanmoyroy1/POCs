export interface CarModel {
  model_name: string;
  model_make_id: string;
}
