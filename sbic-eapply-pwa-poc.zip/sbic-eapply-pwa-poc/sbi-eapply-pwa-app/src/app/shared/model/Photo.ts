export class Photo {
  filename: string;
  content: any;
}
