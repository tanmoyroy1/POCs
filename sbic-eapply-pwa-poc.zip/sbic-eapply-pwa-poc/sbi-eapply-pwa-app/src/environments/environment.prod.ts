export const environment = {
  production: true,
  version: "1.2 PROD",
  car_info_api_url: "https://www.carqueryapi.com/api/0.3/?callback=?&",
  main_api_url: "http://localhost:9000",
  vapid_public_key: "BFRAR28u6JLh_bC-3aTQr-tECmen5wAZkhjnMTeSoJe1n7aXIsJuqv5yayBCvgB7rZhBJG1Zv5ld3dONY4itQE8"
};
